const PRODUCTS = [
  { name: "Chokolade", price: 35 },
  { name: "Saltkaramelis", price: 30 },
  { name: "Bananis", price: 30 },
  { name: "Mangois", price: 30 }
];
const WEEKLY_LIMIT = 5;
const STORAGE_KEY = "vejbos_is_demo_orders_v1";
const POINTS_KEY = "vejbos_is_demo_points_v1";
const $ = (id) => document.getElementById(id);
const money = (n) => `${Math.round(n)} kr.`;
const readOrders = () => { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; } };
const saveOrders = (orders) => localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
const dateOnly = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const dateString = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const parseLocalDate = (s) => { const [y,m,d] = s.split("-").map(Number); return new Date(y,m-1,d); };
const weekKey = (date) => { const d = dateOnly(date); const day = (d.getDay()+6)%7; d.setDate(d.getDate()-day); return dateString(d); };

function renderFlavorSelectors() {
  const count = Number($("quantity").value);
  const host = $("flavorSelectors");
  const old = [...host.querySelectorAll("select")].map(s => s.value);
  host.innerHTML = "";
  for (let i=0; i<count; i++) {
    const label = document.createElement("label");
    label.textContent = `Smag i bæger ${i+1}`;
    const select = document.createElement("select");
    select.required = true;
    select.setAttribute("aria-label", `Smag i bæger ${i+1}`);
    PRODUCTS.forEach((p, idx) => {
      const option = document.createElement("option");
      option.value = String(idx); option.textContent = p.name;
      select.appendChild(option);
    });
    select.value = old[i] ?? "0";
    select.addEventListener("change", updateTotal);
    label.appendChild(select); host.appendChild(label);
  }
  updateTotal();
}
function currentSubtotal() {
  return [...$("flavorSelectors").querySelectorAll("select")].reduce((sum, s) => sum + PRODUCTS[Number(s.value)].price, 0);
}
function discountAmount(subtotal) {
  return $("coupon").dataset.valid === "yes" ? subtotal * .10 : 0;
}
function updateTotal() {
  const subtotal = currentSubtotal();
  $("totalPrice").textContent = money(subtotal - discountAmount(subtotal));
}
function populateDates() {
  const select = $("pickupDate"); select.innerHTML = "";
  const today = dateOnly(new Date());
  for (let i=2; i<=60; i++) {
    const d = new Date(today); d.setDate(today.getDate()+i);
    const opt = document.createElement("option");
    opt.value = dateString(d);
    opt.textContent = d.toLocaleDateString("da-DK",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
    select.appendChild(opt);
  }
  updateCapacity();
}
function bookedInWeek(date) {
  const key = weekKey(date);
  return readOrders().filter(o => o.status === "Aktiv" && weekKey(parseLocalDate(o.pickupDate)) === key)
    .reduce((sum,o)=>sum+o.quantity,0);
}
function updateCapacity() {
  const d = parseLocalDate($("pickupDate").value);
  const booked = bookedInWeek(d);
  const remaining = WEEKLY_LIMIT - booked;
  $("capacityMessage").textContent = remaining > 0
    ? `Denne uge har ${remaining} af ${WEEKLY_LIMIT} bægre tilbage i demoen.`
    : "Denne uge er fuldt booket i demoen. Vælg en anden uge.";
  $("capacityMessage").classList.toggle("capacity-full", remaining <= 0);
}
function refreshProfile() {
  const orders = readOrders();
  $("pointsBalance").textContent = localStorage.getItem(POINTS_KEY) || "0";
  $("myOrders").innerHTML = "";
  if (!orders.length) { $("myOrders").textContent = "Du har ingen bestillinger endnu."; return; }
  orders.slice().reverse().forEach(o => {
    const div = document.createElement("div"); div.className = "order-item";
    const title = document.createElement("b"); title.textContent = `${o.id} · ${o.status}`;
    const detail = document.createElement("div"); detail.textContent = `${o.quantity} bæger(e) · ${o.flavors.join(", ")} · ${o.pickupDate} · ${money(o.total)}`;
    div.append(title,detail); $("myOrders").appendChild(div);
  });
}
function showMessage(el, text, good=true) {
  el.textContent = text; el.style.color = good ? "var(--green)" : "#a13d32";
}

$("quantity").addEventListener("change", renderFlavorSelectors);
$("pickupDate").addEventListener("change", updateCapacity);
$("applyCoupon").addEventListener("click", () => {
  const code = $("coupon").value.trim().toUpperCase();
  const valid = code === "IS10";
  $("coupon").dataset.valid = valid ? "yes" : "no";
  showMessage($("couponMessage"), valid ? "Rabatkode anvendt: 10 % rabat." : (code ? "Rabatkoden blev ikke genkendt." : "Skriv en rabatkode først."), valid);
  updateTotal();
});
$("orderForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const date = parseLocalDate($("pickupDate").value);
  const quantity = Number($("quantity").value);
  const flavors = [...$("flavorSelectors").querySelectorAll("select")].map(s=>PRODUCTS[Number(s.value)].name);
  if (dateOnly(date) < dateOnly(new Date()) || (dateOnly(date)-dateOnly(new Date()))/86400000 < 2) {
    showMessage($("orderResult"), "Vælg en afhentningsdato mindst 2 dage frem.", false); return;
  }
  if (bookedInWeek(date) + quantity > WEEKLY_LIMIT) {
    showMessage($("orderResult"), "Der er ikke nok ledig kapacitet i den uge. Vælg en anden dato.", false); return;
  }
  const subtotal = currentSubtotal(), total = Math.round(subtotal-discountAmount(subtotal));
  const order = {
    id: `VJ-${Math.floor(100000+Math.random()*900000)}`,
    name: $("customerName").value.trim(),
    contact: $("customerContact").value.trim(),
    quantity, flavors, pickupDate: $("pickupDate").value, total,
    status: "Aktiv", createdAt: new Date().toISOString()
  };
  const orders = readOrders(); orders.push(order); saveOrders(orders);
  const points = Number(localStorage.getItem(POINTS_KEY)||"0") + total;
  localStorage.setItem(POINTS_KEY, String(points));
  showMessage($("orderResult"), `Tak for din bestilling! Dit bestillingsnummer er ${order.id}. Gem nummeret til dine noter.`);
  $("orderForm").reset(); $("quantity").value = "1"; $("coupon").dataset.valid = "no";
  renderFlavorSelectors(); populateDates(); refreshProfile();
});
$("cancelForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const id = $("cancelId").value.trim().toUpperCase();
  const contact = $("cancelContact").value.trim().toLowerCase();
  const orders = readOrders();
  const order = orders.find(o=>o.id.toUpperCase()===id && o.contact.toLowerCase()===contact && o.status==="Aktiv");
  if (!order) { showMessage($("cancelMessage"), "Vi fandt ikke en aktiv ordre med de oplysninger i denne browser.", false); return; }
  const days = (dateOnly(parseLocalDate(order.pickupDate))-dateOnly(new Date()))/86400000;
  if (days < 2) { showMessage($("cancelMessage"), "Ordren kan ikke afbestilles her, fordi afhentningen er mindre end 2 dage væk. Kontakt vejbois@gmail.com.", false); return; }
  order.status = "Afbestilt"; saveOrders(orders);
  showMessage($("cancelMessage"), `Ordre ${order.id} er afbestilt i demoen.`);
  updateCapacity(); refreshProfile();
});
$("menuToggle").addEventListener("click", () => {
  const nav = $("mainNav"), open = nav.classList.toggle("open");
  $("menuToggle").setAttribute("aria-expanded", String(open));
});
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>{$("mainNav").classList.remove("open");$("menuToggle").setAttribute("aria-expanded","false")}));
$("year").textContent = new Date().getFullYear();
renderFlavorSelectors(); populateDates(); refreshProfile();