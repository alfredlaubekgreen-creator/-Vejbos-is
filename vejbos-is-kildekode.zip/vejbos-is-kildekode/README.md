# Vejbos Is – kildekode

Dette er en genskabt, responsiv version af Vejbos Is-hjemmesiden baseret på den offentligt synlige side.

## Filer
- `index.html` – sidens indhold og formularer
- `styles.css` – design, farver og mobilvisning
- `app.js` – smagsvalg, prisberegning, afhentningsdatoer, demo-bestillinger, point og afbestilling

## Sådan åbner du siden
1. Pak ZIP-filen ud.
2. Åbn `index.html` i en browser for at prøve siden lokalt.
3. Upload de tre webfiler til dit webprojekt/Cloudflare Pages.

## Vigtigt før siden bruges rigtigt
Denne udgave er en **frontend-demo**. Bestillinger og point gemmes kun i browserens `localStorage` på den enhed, hvor siden bruges. Det betyder:
- Kunder og ejeren kan ikke se de samme ordrer fra forskellige enheder.
- Der sendes ikke automatisk e-mail eller SMS.
- Der er ikke rigtig konto/login, sikker administrator-side, database eller betalingsintegration.
- Rabatkoden `IS10` er kun en eksempelrabat og kan ændres i `app.js`.

Brug ikke demoen til at modtage rigtige kunders kontaktoplysninger eller rigtige ordrer. Før offentlig brug skal der tilkobles en sikker backend/database med server-side validering, adgangskontrol og passende håndtering af personoplysninger. Få en voksen til at hjælpe med opsætning og gennemgang af bestillings- og fødevareoplysninger.

## Tilpasning
I `app.js` kan du ændre:
- Smagsnavne og priser i `PRODUCTS`
- Ugens samlede kapacitet i `WEEKLY_LIMIT`
- Rabatkoden i event listeneren til `applyCoupon`

I `index.html` kan du ændre tekster, kontaktoplysninger og sektioner.
